/**
 * 
 */
package appmain;

/**
 * @author Jahangir Ismail
 * Student ID: A00036852
 * Created on Feb. 14, 2022 9:05:28 p.m.
 */
public class Main {

}
