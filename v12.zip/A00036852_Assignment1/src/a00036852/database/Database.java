/**
 * Purpose of Database class:
 * Load JDBC driver
 * Establish DB connection
 * Close Connection
 */
package a00036852.database;

import java.sql.*;

/**
 * @author Jahangir Ismail
 * Student ID: A00036852
 * Handle the Database connections, close connection
 */
public class Database {
	
	
	private String driver;
	private String url;
	private String user;
	private String password;
	
	private Connection conn; // connection to DB
	
	
	
	public Database() {
		// get DB info from the DBUtils
		DBUtils dbu = new DBUtils();
		driver = dbu.getDBDriver();
		url = dbu.getURL();
		user = dbu.getDBUser();
		password = dbu.getDBPassword();
		
		loadDriver(); // load the driver
	}

	// load Database driver for derby
	private void loadDriver() {
		try {
			Class.forName(driver);
		}catch(ClassNotFoundException c) {
			c.printStackTrace();
		}
	}
	
	// connect to DB
	/**
	 * connect to DB
	 */
	public void connect() {
		// check if connection is null
		if(conn == null) {
			
			loadDriver(); // load driver, otherwise Connection wont work.
		}
		try {
		 conn = DriverManager.getConnection(url, user, password);
		 //System.out.println("Database connected");
		}catch(SQLException s) {
			s.printStackTrace();
		}
		
	}
	
	// create a table
	/**
	 * 
	 * @param sql
	 */
	public void creatTable(String sql) {
		//System.out.println("\nDatabase.createTable() called..\n");
		connect(); // connect to DB, may have been closed
		
		try {
			Statement state = conn.createStatement();
			state.executeUpdate(sql) ;
				//System.out.println("Create Table success :> " + sql);
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	// insert a record
	/**
	 * 
	 * @param sql
	 */
	public void insert(String sql) {
		//System.out.println("\nDatabase.insert() called..");
		connect(); // connect to DB, may have been closed
		
		try{
			
			Statement st = conn.createStatement();
			st.executeUpdate(sql) ;
				//System.out.println("insert success");
		
		}catch(SQLException s) {
			s.printStackTrace();
		}
	}
	
	// get a record
	public void find(String sql) {
		//System.out.println("\nDatabase.find() called ..\n");
		connect();
		
	}
	
	// close connection
	public void shutdown() {
		if(conn != null) {
			try {
				conn.close();
				conn = null;
				System.out.println("Connection closed");
			}catch(SQLException s) {
				s.printStackTrace();
			}
		}
	}
	
	// check if Table exists
	/**
	 * 
	 * @param tableName
	 * @return boolean 
	 * @throws SQLException
	 */
	public boolean tableExists(String tableName) throws SQLException {
		DatabaseMetaData databaseMetaData = conn.getMetaData();
		ResultSet resultSet = null;
		String rsTableName = null;

		try {
			resultSet = databaseMetaData.getTables(conn.getCatalog(), "%", "%", null);
			while (resultSet.next()) {
				rsTableName = resultSet.getString("TABLE_NAME");
				if (rsTableName.equalsIgnoreCase(tableName)) {
					return true;
				}
			}
		} finally {
			resultSet.close();
		}

		return false;
	}
	
	// delete table from DB
	/**
	 * 
	 * @param table name of table to drop
	 * @return boolean status
	 * @throws SQLException
	 */
	public  boolean dropTable(String table) throws SQLException{
		boolean status = false;
		connect();
		
		if(tableExists(table)) {
			Statement st = conn.createStatement();
			st.executeUpdate(String.format("drop table %s", table));
			status = true;
		}
		
		return status;
	}
	
	
		
	/**
	 * 
	 * @return Connection
	 */
	public Connection getConnection() {
		return conn;
	}
	
}
