/**
 * 
 */
package appmain;

import java.awt.EventQueue;
import java.sql.SQLException;

import a00036852.database.Database;

/**
 * @author Jahangir Ismail
 * Student ID: A00036852
 * Created on Feb. 14, 2022 9:05:28 p.m.
 */
public class Main {
	
	
	public Main() {
		System.out.println("Starting main...");
		
		// init the DB
		Database db = new Database();
		try {
			db.connect(); // connect to Db
			// do a simple check
			if(db.tableExists("pets"))
				System.out.println("pets exists");
			else
				System.out.println("pets doesn't exist");
			
			db.shutdown(); // shut it down
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}finally{
			db.shutdown();
		}
		
		// read data file
		
		// run the Window Frame
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JApp window = new JApp();
					window.show();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public static void main(String[] args) {
		new Main();
	}

}
