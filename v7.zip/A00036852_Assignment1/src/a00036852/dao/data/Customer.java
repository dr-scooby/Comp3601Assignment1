package a00036852.dao.data;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * @author  Jahangir Ismail
 * Student ID: A00036852
 *  Customer class holds the customer info.
 *  This is used by the Model in MVC.
 *  @version 1
 */

public class Customer {
	
	// -- Data Variables
	private final int ID;	
	private final String firstName;
	private final String lastName;
	private final String streetName;
	private final String city;
	private final String postal;
	private final String phone;	
	private final String email;
	private final LocalDate date ;
	
	// private Constructor
	/**
	 * Private Constructor, prevent class from being created from the outside
	 * @param builder
	 */
	private Customer(Builder builder) {
		ID = builder.ID;
		firstName = builder.Firstname;
		lastName = builder.Lastname;
		streetName = builder.Streetname;
		city = builder.City;
		postal = builder.Postal;
		phone = builder.Phone;
		email = builder.Email;
		date = builder.date;
	}
	
	// -- Inner class Builder --
	/**
	 * Inner Class Builder
	 * @author J. Ismail
	 *
	 */
	public static class Builder{
		// Required params
		private final int ID;
		private final String Phone;
		
		// optional params
		private String Firstname;
		private String Lastname;
		private String Streetname;
		private String City;
		private String Postal;			
		private String Email;
		private LocalDate date  ;
		
		
		/**
		 * Init the required Fields ID & Phone
		 * @param ID - integer 
		 * @param phone - String
		 */
		public Builder(int ID, String phone) {
			this.ID = ID;
			this.Phone = phone;
		}
		
		/**
		 * 
		 * @param String fname
		 * @return Builder
		 */
		public Builder setFirstName(String fname) {
			this.Firstname = fname;
			
			return this;
		}
		
		/**
		 * 
		 * @param String lname
		 * @return Builder
		 */
		public Builder setLastName(String lname) {
			this.Lastname = lname;
			
			return this;
		}
		
		/**
		 * 
		 * @param String street
		 * @return Builder
		 */
		public Builder setStreetname(String street) {
			this.Streetname = street;
			
			return this;
		}
		
		/**
		 * 
		 * @param String city
		 * @return Builder
		 */
		public Builder SetCity(String city) {
			this.City = city;
			
			return this;
		}
		/**
		 * 
		 * @param String postal
		 * @return Builder
		 */
		public Builder setPostal(String postal) {
			this.Postal = postal;
			
			return this;
		}
		
		/**
		 * 
		 * @param String email
		 * @return Builder
		 */
		public Builder setEmail(String email) {
			this.Email = email;
			
			return this;
		}
		
		/**
		 * 
		 * @param LocalDate date
		 * @return Builder
		 */
		public Builder setDate(LocalDate date) {
			this.date = date;
			
			return this;
		}
		
		public Builder setDate(String date) {
			this.date = LocalDate.parse(date);
			
			return this;
		}

		/**
		 * 
		 * @return int
		 */
		public int getID() {
			return ID;
		}

		/**
		 * 
		 * @return String
		 */
		public String getPhone() {
			return Phone;
		}

		public String getFirstname() {
			return Firstname;
		}

		public String getLastname() {
			return Lastname;
		}

		public String getStreetname() {
			return Streetname;
		}

		public String getCity() {
			return City;
		}

		public String getPostal() {
			return Postal;
		}

		public String getEmail() {
			return Email;
		}

		/**
		 * 
		 * @return date LocalDate
		 */
		public LocalDate getDate() {
			return date;
		}
		
		/**
		 * 
		 * @return String Date as String
		 */
		public String getDateString() {
			String result = date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
			return result;
		}
		
		// *** important to return the new Class object Customer
		public Customer build() {
			return new Customer(this);
		}
		
	}//--- end inner class ---
	
	
	
	
	// -- Get & Set methods
	
	public String getFirstName() {
		return firstName;
	}
	public int getID() {
		return ID;
	}
	
	public String getLastName() {
		return lastName;
	}
	
	public String getStreetName() {
		return streetName;
	}
	
	public String getCity() {
		return city;
	}
	
	public String getPostal() {
		return postal;
	}
	
	public String getPhone() {
		return phone;
	}
	
	public String getEmail() {
		return email;
	}
	
	public LocalDate getDate() {
		return date;
	}
	
	/**
	 * 
	 * @return String Date
	 */
	public String getDateString() {
		String result = date.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		return result;
	}
	
	
	
	@Override
	public String toString() {
		return "Customer [ID=" + ID + ", firstName=" + firstName + ", lastName="+ lastName + ", street="+  streetName  + ", city="+ city+ ", postalCode="+ postal +  ", Phone=" + phone + ", emailAddress=" + email + ", joineDate= "+ date + "]";
	}
	
	

	
}
