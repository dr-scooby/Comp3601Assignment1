package a00036852.windowapp;

import java.awt.Desktop.Action;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.KeyStroke;
import javax.swing.AbstractAction;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.SwingConstants;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.sql.SQLException;
import java.util.*;

import a00036852.dao.CustomerDAO;
import a00036852.dao.data.Customer;
import a00036852.database.DBConstants;
import a00036852.database.Database;
import a00036852.io.*;
import a00036852.data.util.*;

import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

// the JSwing Window app
/**
 * The main JWindow
 * @author Jahangir Ismail
 * Student ID: A00036852
 * Created on Mar. 1, 2022 
 */
public class JApp {

	private JFrame frmAssignment;
	
	private JCheckBox chckbxJoinDate;
	
	private JCheckBox chckbxFName;
	
	private JCheckBox chckbxLName;
	
	private JCheckBox chckbxID;
	
	private Database db; // handle to the Database
	
	private CustomerDAO cdao; // handle to the DAO
	
	private boolean sortbydate;
	private boolean sortbyFName;
	private boolean sortbyLName;
	private boolean sortbyID;
	

	/**
	 * Launch the application. this main for testing the JFrame works
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					JApp window = new JApp();
//					window.frmAssignment.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the application.
	 */
	public JApp() {
		initialize();
	}
	
	public void show() {
		frmAssignment.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAssignment = new JFrame();
		frmAssignment.setTitle("Assignment 1");
		frmAssignment.setBounds(100, 100, 663, 490);
		frmAssignment.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();
		frmAssignment.setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("File");
		mnNewMenu.setMnemonic(KeyEvent.VK_F);
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Drop");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Drop");
				drop();
			}
		});
		mntmNewMenuItem.setHorizontalAlignment(SwingConstants.LEFT);
		mnNewMenu.add(mntmNewMenuItem);
		
		JSeparator separator = new JSeparator();
		mnNewMenu.add(separator);
		
		JMenuItem itemQuit = new JMenuItem("Quit");
		itemQuit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Quit called...bye...");
				exitMe();
			}
		});
		itemQuit.setHorizontalAlignment(SwingConstants.LEFT);
		KeyStroke keyStrokeToQuit  = KeyStroke.getKeyStroke(KeyEvent.VK_Q, KeyEvent.CTRL_DOWN_MASK);
		itemQuit.setAccelerator(keyStrokeToQuit);
		mnNewMenu.add(itemQuit);
		
		JMenu mnNewMenu_1 = new JMenu("Customers");
		mnNewMenu_1.setMnemonic(KeyEvent.VK_C); 
		menuBar.add(mnNewMenu_1);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Count");
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Count");
				count();
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_2);
		
		chckbxJoinDate = new JCheckBox("By Join Date");
		chckbxJoinDate.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED) {
					System.out.println("Check box selected");
					
					checkDate(true);
				}
				
				else
					if(e.getStateChange() == ItemEvent.DESELECTED) {
						System.out.println("Deselect");
						//sortbydate = false;
						checkDate(false);
					}
			}
		});
		mnNewMenu_1.add(chckbxJoinDate);
		
		chckbxFName = new JCheckBox("By First Name");
		chckbxFName.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				
				
				if(e.getStateChange() == ItemEvent.SELECTED) {
					System.out.println("Check box selected");
					// check box selected
					checkFName(true);
				}else if(e.getStateChange() == ItemEvent.DESELECTED) {
					System.out.println("Deselect");
					//sortbyFName = false;
					checkFName(false);
				}
				
			}
		});
		mnNewMenu_1.add(chckbxFName);
		
		chckbxLName = new JCheckBox("By Last Name");
		chckbxLName.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED) {
					checkLName(true);
				}else if(e.getStateChange() == ItemEvent.DESELECTED) {
					checkLName(false);
				}
			}
		});
		mnNewMenu_1.add(chckbxLName);
		
		chckbxID = new JCheckBox("By ID");
		chckbxID.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				if(e.getStateChange() == ItemEvent.SELECTED) {
					checkID(true);
				}else if(e.getStateChange() == ItemEvent.DESELECTED) {
					checkID(false);
				}
			}
		});
		mnNewMenu_1.add(chckbxID);
		
		JSeparator separator_1 = new JSeparator();
		mnNewMenu_1.add(separator_1);
		
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("List");
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("List");
				list();
			}
		});
		mnNewMenu_1.add(mntmNewMenuItem_3);
		
		JMenu mnNewMenu_2 = new JMenu("Help");
		mnNewMenu_2.setMnemonic(KeyEvent.VK_H);
		menuBar.add(mnNewMenu_2);
		
		JMenuItem mntmNewMenuItem_4 = new JMenuItem("About");
		KeyStroke keyStrokeAbout = KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0);
		mntmNewMenuItem_4.setAccelerator(keyStrokeAbout);
		mntmNewMenuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("About");
				about();
			}
		});
		mntmNewMenuItem_4.setMnemonic(KeyEvent.VK_F1);
				
		
		mnNewMenu_2.add(mntmNewMenuItem_4);
	}
	
	//-- following methods to check which JCheckBox is selected, 
	//-- then un-check the other CheckBoxes
	
	// used for the check box join date
	private void checkDate(boolean chek) {
		
		if(chek) {
			sortbydate = true;
			sortbyFName = false;
			chckbxFName.setSelected(false);
			sortbyLName = false;
			chckbxLName.setSelected(false);
			sortbyID = false;
			chckbxID.setSelected(false);
		}else {
			sortbydate = false;
			
		}		
		
	}
	
	// used to check the First Name check box is selected, de-selected
	private void checkFName(boolean chek) {
		
		if(chek) {
			sortbyFName = true;
			sortbydate = false;
			chckbxJoinDate.setSelected(false);
			sortbyLName = false;
			chckbxLName.setSelected(false);
			sortbyID = false;
			chckbxID.setSelected(false);
		}else {
			sortbyFName = false;
		}
	}
	
	// used to check the Last Name check box is selected, de-selected
	private void checkLName(boolean chek) {
		
		if(chek) {
			sortbyLName = true;
			
			sortbydate = false;
			chckbxJoinDate.setSelected(false);
			sortbyFName = false;
			chckbxFName.setSelected(false);
			sortbyID = false;
			chckbxID.setSelected(false);
		}else {
			sortbyLName = false;
		}
	}
	
	// used to check the ID check box is selected, de-selected
	private void checkID(boolean chek) {
		
		if(chek) {
			sortbyID = true;
			
			sortbydate = false;
			chckbxJoinDate.setSelected(false);
			sortbyFName = false;
			chckbxFName.setSelected(false);
			sortbyLName = false;
			chckbxLName.setSelected(false);
		}else {
			sortbyID = false;
		}
	}
	
	// count customers
	private void count() {
		int amount = cdao.getCount(); // get from DB
		// now show
		JOptionPane.showMessageDialog(frmAssignment, "Total Customer Count: " + amount, "Customer Count", JOptionPane.PLAIN_MESSAGE);
	}
	
	// drop the table
	private void drop() {
		String message = "Are you sure you want to drop the Table?";
		Object[] options = {"Yes, please", "No way!"};
		int x = JOptionPane.showOptionDialog(frmAssignment, message, "drop table", JOptionPane.YES_NO_OPTION, JOptionPane.ERROR_MESSAGE, null, options, options[1]);
		if(x == 0) {
			System.out.println("0"); // yes selection
			try {
				if(db == null) {
					System.out.println("DB null");
				}else
					db.dropTable(DBConstants.CUSTOMER_TABLE);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				JOptionPane.showMessageDialog(frmAssignment, "error dropping table", "SQL Error", JOptionPane.ERROR_MESSAGE);
			}
		}
		if(x > 0)
			System.out.println("greater than 0"); // no selection
	}
	
	// about app
	private void about() {
		String message = "Assignment 1 \nStudent: Jahangir Ismail\nID: A00036852\nCustomer application to view, update/edit Customer info and store to the DB.\nDB: Derby DB";
		JOptionPane.showMessageDialog(frmAssignment, message, "About", JOptionPane.PLAIN_MESSAGE);
	}
	
	// list the customers
	private void list() {

		ArrayList<Customer> customers = new ArrayList<Customer>();
		List<String> listids;
		
		if(cdao.tableExist()) {
		try {
			listids = cdao.getIds();
			if(listids.isEmpty()) {
				System.out.println("list is empty");
			}
			Customer c = null;
			int idint = 0;
			Iterator it = listids.iterator();
			while(it.hasNext()) {
				String val = (String) it.next(); // do a cast on the object to String
				idint = Integer.parseInt(val); //  cast to int
				try {
					c = cdao.getCustomer(idint); // get Customer from the DB
					customers.add(c); // add to the Array
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		//-- do a sort on the list
		if(sortbydate)
			customers.sort( new CompareByJoinedDate());
		
		if(sortbyFName)
			customers.sort(new CompareByFirstName());
		
		if(sortbyLName)
			customers.sort(new CompareByLastName());
		
		if(sortbyID)
			customers.sort(new CompareById());
		
		// -- show the Customer listing dialog --//
		try {
			CustomerListDialog dialog = new CustomerListDialog(frmAssignment, customers);
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setDAO(cdao);
			dialog.setVisible(true);
			if(dialog.isUpdate()) {
				System.out.println("time to update the DB..");
				//cdao.update(dialog.getUpdateCustomer());
				customers.clear(); // clear
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		}else {
			JOptionPane.showMessageDialog(frmAssignment, "Table doesn't exist");
		}
		
	}
	
	
	/**
	 * set the CustomerDAO
	 * @param d CustomerDAO
	 */
	public void setCustomerDAO(CustomerDAO d) {
		this.cdao = d;
	}
	
	/**
	 * set the Database
	 * @param d Database
	 */
	public void setDB(Database d) {
		this.db = d;
	}
	
	// exit the app
	private void exitMe() {
		// check if DB is not null, then shutdown DB
		if(db != null)
			db.shutdown();
		System.exit(0);
	}

}
