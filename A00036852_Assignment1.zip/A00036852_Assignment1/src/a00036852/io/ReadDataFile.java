/**
 * 
 */
package a00036852.io;

import java.io.*;
import java.util.*;

//import a00036852.database.DBConstants;

/**
 * @author Jahangir Ismail
 * Student ID: A00036852
 * Created on Feb. 9, 2022 
 */
public class ReadDataFile {
	
	private String filename = "data/customers.dat";
	
	private File f ;
	
	private ArrayList<String> rawdata;
	
	
	// Read data file
	public ReadDataFile() {
		f = new File(filename);
		if(f.exists()) {
			//System.out.println("Data file exists: " + f.getAbsolutePath());
			rawdata = new ArrayList<String>();
			try {
				int headerline = 0;
				BufferedReader inb = new BufferedReader(new FileReader(f));
				String s = new String();
				try {
					while( (s = inb.readLine()) != null ) {
						if(headerline >= 1) {
							rawdata.add(s); // add the line to the Array
							//System.out.println("The Line: \n" + s );
							//processLine(s);
						}
						
						if(headerline == 0)
							headerline++;
						
						
					}
					inb.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else
			System.out.println("Can't get file");
	}
	
	private void processLine(String s) {
		String[] data = s.split("\\|");
		
		for(String s1 : data) {
			System.out.println(s1);
		}
	}
	
	/**
	 * 
	 * @return ArrayList<String>
	 */
	public ArrayList<String> getDataArray() {
		return rawdata;
	}

}
