/**
 * 
 */
package a00036852.data.util;

import java.time.LocalDate;
import java.util.*;

import a00036852.dao.data.Customer;

/**
 * @author Jahangir Ismail
 * Student ID: A00036852
 * Created on Feb. 10, 2022 
 * Take an Array of Strings, and convert to a collection of Customer objects
 */
public class ProcessArray {
	
	private ArrayList<String> rawdata;
	
	private Collection<Customer> customers;
	
	
	
	public ProcessArray() {
		customers = new ArrayList<Customer>();
	}
	
	
	/**
	 * Take an ArrayList of raw data
	 * @param ar ArrayList<String>
	 */
	public ProcessArray(ArrayList<String> ar) {
		this(); // important to call, otherwise customers will be null
		this.rawdata = ar;
		process();
	}
	
	// take Array of Strings and convert to Array of Customers
	/**
	 * 
	 * @param ar ArrayList<String>
	 */
	public void process(ArrayList<String> ar) {
		customers = new ArrayList<Customer>();
		this.rawdata = ar;
		process();
	}
	
	/**
	 * process the Array of Strings, convert to Array of Customers
	 */
	private void process() {
		customers.clear(); // clear customers first
		// iterate over rawdata
		Iterator it = rawdata.iterator();
		while(it.hasNext()) {
			String dataline = (String)it.next(); // cast object to String
			String[] dataarr = dataline.split("\\|"); // split the String by | and place in array[]
			Customer c;
			int id = 0;
			String phone = "";
			String fname = "";
			String lname = "";
			String address = "";
			String city = "";
			String postal = "";
			String email = "";
			LocalDate date = null ;
			
			for(int i = 0; i < dataarr.length; i++) {
				switch(i) {
				case 0: 
					// parse the first string into an int
					id = Integer.parseInt(dataarr[i]);					
					break;
				case 1:
					// grab first name
					fname = dataarr[i].strip().trim();
					break;
				case 2:
					// grab last name
					lname = dataarr[i].strip().trim();
					break;
				case 3:
					// get the address, street name
					address = dataarr[i].strip().trim();
					break;
				case 4:
					// get the city
					city = dataarr[i].strip().trim();
					break;
				case 5:
					// get the postal code
					postal = dataarr[i].strip().trim();					
					break;
				case 6:
					// get the phone
					phone = dataarr[i].strip().trim();					
					break;
				case 7:
					// get help from the Validator class to validate the email
					email = Validator.processEmail(dataarr[i]);					
					break;
				case 8:
					// process and get the date
					date = Validator.processDate( dataarr[i].strip().trim() );
					break;
				default:
					System.out.println("unknown");
					break;
				
				
				}// end switch
			}// end for loop
			
			// create the Customer providing the data
			c = new Customer.Builder(id, phone).setFirstName(fname).setLastName(lname).setStreetname(address).SetCity(city).setPostal(postal).setEmail(email).setDate(date).build();
			// add to customers
			customers.add(c);
			
		}// end while it
	}
	
	/**
	 * 
	 * @return Collection<Customer> ArrayList of Customer
	 */
	public Collection<Customer> getCustomers() {
		return  customers;
	}
	
	/**
	 * 
	 * @return Iterator of Customers
	 */
	public Iterator getIt() {
		return customers.iterator();
	}
	
	/**
	 * 
	 * @return int customers size
	 */
	public int getCustomerSize() {
		return customers.size();
	}

}
