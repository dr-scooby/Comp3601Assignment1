
package a00036852.data.util;

import java.util.Comparator;
import java.time.LocalDate;

import a00036852.dao.data.Customer;
import a00036852.data.*;


/**
 * @author  Jahangir Ismail
 * Sort by Joined Date using Comparator
 */
public class CompareByJoinedDate implements Comparator<Customer>{
	
	
	
	// Take 2 Customer objects and compare by date
	/**
	 * @param Customer c1, Customer c2
	 * @return int
	 */
	public int compare(Customer c1, Customer c2) {
		LocalDate d1 = c1.getDate();
		LocalDate d2 = c2.getDate();
		return  d1.compareTo(d2);
	}
	
	

}
