/**
 * 
 */
package a00036852.data.util;

import java.util.Comparator;

import a00036852.dao.data.Customer;

/**
 * @author Jahangir Ismail
 * Student ID: A00036852
 * Created on Feb. 24, 2022 
 */
public class CompareById implements Comparator<Customer>{
	
	
	public int compare(Customer c1, Customer c2) {
		
				
		return c1.getID() - c2.getID();
		
	}

}
