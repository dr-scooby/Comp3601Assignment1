
package a00036852.data.util;
import java.util.*;

import a00036852.dao.data.Customer;
import a00036852.data.*;
import a00036852.data.util.*;


/**
 * @author Jahangir
 * Student ID: A00036852
 * Sort by Last Name using Comparator
 */
public class CompareByLastName implements Comparator<Customer>{
	
	
	public int compare(Customer c1, Customer c2) {
		String l1 = c1.getLastName();
		String l2 = c2.getLastName();
		
		return l1.compareTo(l2);
		
	}

}
