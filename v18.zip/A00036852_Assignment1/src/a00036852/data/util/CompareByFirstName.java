/**
 * Sort Customer by First Name
 */
package a00036852.data.util;
import java.util.Comparator;
import a00036852.*;
import a00036852.dao.data.Customer;
import a00036852.data.*;

/**
 * @author Jahangir Ismail
 * Student ID: A00036852
 * Sort by First Name using Comparator
 */
public class CompareByFirstName implements Comparator<Customer>{
	
	// implement the compare
	// take 2 customers to compare
	/**
	 * @param Customer
	 */
	public int compare(Customer c1, Customer c2) {
		// get the first names
		String f1 = c1.getFirstName();
		String f2 = c2.getFirstName();
		
		return f1.compareTo(f2); // return the compareTo int
	}

}
