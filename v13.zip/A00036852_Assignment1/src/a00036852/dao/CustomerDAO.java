/**
 * 
 */
package a00036852.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;

import java.util.*;

import a00036852.dao.data.Customer;
import a00036852.data.util.Validator;
import a00036852.database.DBConstants;
import a00036852.database.Database;

/**
 * @author Jahangir Ismail
 * CustomerDAO - Data Access Object of Customers
 */
public class CustomerDAO extends Dao{
	
	private static String Table_Name = DBConstants.CUSTOMER_TABLE;
	
	private Database db; // handle to the Database;
	
	
	public CustomerDAO(Database d) {
		super(d, Table_Name);
		this.db = d;
	}
	
	// Create the table
	@Override
	public void create() throws SQLException{
		
		String create = String.format(
				"create table %s(customerId INTEGER, firstName VARCHAR(40), lastName VARCHAR(40), street VARCHAR(40), city VARCHAR(40), postal VARCHAR(40)"
				+ ", phone VARCHAR(40), email VARCHAR(40), Date VARCHAR(40) )", 
				Table_Name);
		
		String sql_create = String.format("create table %s(" // 1
				+ "%s VARCHAR(10), " // 2 - customer id - VARCHAR
				+ "%s VARCHAR(20), " // 3 - fname
				+ "%s VARCHAR(20), " // 4 - lname
				+ "%s VARCHAR(40), " // 5 - street
				+ "%s VARCHAR(40), " // 6 - city
				+ "%s VARCHAR(6), " // 7 - postal
				+ "%s VARCHAR(10), " // 8 - phone
				+ "%s VARCHAR(50), " // 9 - email
				+ "%s VARCHAR(15), " // 10 - Date
				+ "primary key (%s) )", // 12, 					
				tablename, 
				Fields.CUSTOMER_ID.getName(),
				Fields.FIRST_NAME.getName(),
				Fields.LAST_NAME.getName(),
				Fields.STREET.getName(),
				Fields.CITY.getName(),
				Fields.POSTAL.getName(),
				Fields.PHONE.getName(),
				Fields.EMAIL.getName(),
				Fields.DATE.getName(),
				Fields.CUSTOMER_ID.getName()
				); 
		
		// call super create
		super.create(create);
	}
	
	
	/**
	 * Add a Customer to the DB
	 * @param c Customer
	 * @throws SQLException
	 */
	public void add(Customer c) throws SQLException {
		
//		String ids = Integer.toString(c.getID());
//		System.out.println("ids: " + ids);
		
		String sql = "insert into " + Table_Name + "("+
				Fields.CUSTOMER_ID.getName()
				+ "," + Fields.FIRST_NAME.getName()
				+ "," + Fields.LAST_NAME.getName()
				+ "," + Fields.STREET.getName()
				+ "," + Fields.CITY.getName()
				+ "," + Fields.POSTAL.getName()
				+ "," + Fields.PHONE.getName()
				+ "," + Fields.EMAIL.getName() 
				+ "," + Fields.DATE.getName()
				
				+ ") values(" +c.getID() 
				+",'" + c.getFirstName() 
				+ "','" +	c.getLastName() 
				+ "','" + c.getStreetName()
				+ "','" + c.getCity()
				+ "','" + c.getPostal()
				+ "','" + c.getPhone()
				+ "','" + c.getEmail()
				+ "','" + c.getDate() + "')";
		
		//System.out.println("insert: "  + sql);
		super.add(sql); // call super
	}
	
	
		
	public void update() {
		
	}
	
	
	public void delete() {
		
	}
	

	/**
	 * 
	 * @param id String id to search
	 * @return c Customer
	 * @throws SQLException
	 * @throws Exception
	 */
	public Customer getCustomer(String id) throws SQLException, Exception {
		int intid = Integer.parseInt(id); // convert String to an int
		Customer c = getCustomer(intid); // get a Customer
		// return c Customer
		return c;
	}
	
	/**
	 * Get a Customer by searching by ID
	 * @param searchid String - search by Customer ID
	 * @return Customer c
	 * @throws SQLException
	 * @throws Exception
	 */
	public Customer getCustomer(int searchid) throws SQLException, Exception {
		
		String sql_search = "select * from " + Table_Name + " where customerId = ?";
		//System.out.println("sql_search: " + sql_search);
		// SQL query by CustomerID
		//String sql = String.format("select * from %s where %s = '%s'", Table_Name,  Fields.CUSTOMER_ID.getName(), searchid);
		
		Customer c = null;
		String ids;
		String fname;
		String lname;
		String street;
		String city;
		String postal;
		String phone ;
		String email ;
		String date ;// Fields.DATE.getName();
		
		Connection conn = db.getConnection();
		// use a PreparedStatement
		PreparedStatement ps = conn.prepareStatement(sql_search);
		ps.setInt(1, searchid);
		
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			fname = rs.getString(Fields.FIRST_NAME.getName());
			lname = rs.getString(Fields.LAST_NAME.getName());
			street = rs.getString(Fields.STREET.getName());
			city = rs.getString(Fields.CITY.getName());
			phone = rs.getString(Fields.PHONE.getName());
			postal = rs.getString(Fields.POSTAL.getName());
			email = rs.getString(Fields.EMAIL.getName());
			//LocalDate da = Validator.processDate(Fields.DATE.getName());
			date = rs.getString(Fields.DATE.getName());
			c = new Customer.Builder(searchid, phone).setFirstName(fname).setLastName(lname).setStreetname(street).SetCity(city).setPostal(postal).setEmail(email).setDate(date).build();
			
		}
		

		return c;
	}
	
	public boolean tableExist() {
		boolean exists = false;
		try {
			if(db.tableExists(Table_Name))
				exists = true;
			else 
				exists = false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return exists;
	}
	
	/**
	 * Return a List of customer ID's
	 * @return List<String> List of ID's
	 * @throws SQLException 
	 */
	public List<String> getIds() throws SQLException{
		//System.out.println("getIDs()");
		List<String> ids = new ArrayList<String>();
		
		String sql = "select customerId from " +  Table_Name;
		//System.out.println(sql);
		
		int id = 0;
		Integer tempint = null;
		String sid = "";
		Connection con = db.getConnection();
		Statement st = con.createStatement();
		
		ResultSet rs = st.executeQuery(sql);
		
		while(rs.next()) {
			id = rs.getInt(1); // first column
			sid = Integer.toString(id); // convert int to String
			ids.add(sid); // add to Array
			//System.out.println("adding " + sid);
		}
		
		//System.out.println("size of array : " + ids.size() );
		
		return ids;
	}
	
	
	
	// -------------------------- ENUM ------------------------------- //
	// Enum fields for the table columns
	public enum Fields {
		CUSTOMER_ID("customerId", "VARCHAR", 9, 1), //1
		FIRST_NAME("firstName", "VARCHAR", 20, 2), // 2
		LAST_NAME("lastName", "VARCHAR", 20, 3), // 3
		STREET("street", "VARCHAR", 40, 4), // 4
		CITY("city", "VARCHAR", 40, 5), // 5
		POSTAL("postal", "VARCHAR", 6, 6), // 6
		PHONE("phone", "VARCHAR", 10, 7), // 7
		EMAIL("email", "VARCHAR", 50, 8), // 8
		//DATE("Date", "DATE", -1, 9), //9
		DATE("Date", "VARCHAR", 15, 9), //9
		;
		
		
		private final String name;
		private final String type;
		private final int length;
		private final int column;
		
		Fields(String name, String type, int length, int column){
			this.name = name;
			this.type = type;
			this.length = length;
			this.column = column;
		}
		
		public String getType() {
			return type;
		}
		
		public String getName() {
			return name;
			
		}
		
		public int getLength() {
			return length;
		}
		
		public int getColumn() {
			return column;
		}
	}
}
