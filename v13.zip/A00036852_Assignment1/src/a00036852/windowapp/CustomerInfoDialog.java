package a00036852.windowapp;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import a00036852.dao.data.Customer;

import java.awt.Color;
import javax.swing.border.EtchedBorder;
import java.awt.GridLayout;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Frame;

public class CustomerInfoDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField idTF;
	private JTextField fnameTF;
	private JTextField lnameTF;
	private JTextField streetTF;
	private JTextField cityTF;
	private JTextField postalTF;
	private JTextField phoneTF;
	private JTextField emailTF;
	private JTextField dateTF;

	private Customer customer; // handle to the Customer
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			CustomerInfoDialog dialog = new CustomerInfoDialog();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public CustomerInfoDialog(Frame f, Customer c) {
		super(f, true);
		this.customer = c;
		init();
	}

	/**
	 * Create the dialog.
	 */
	public CustomerInfoDialog() {
		setAlwaysOnTop(true);
		setTitle("Customer Info");
		setBounds(100, 100, 451, 424);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JPanel panel = new JPanel();
			panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
			contentPanel.add(panel);
			panel.setLayout(new MigLayout("", "[1px][1px][1px][][][grow]", "[1px][][][][][][][][][]"));
			{
				JLabel label = new JLabel("");
				panel.add(label, "cell 0 0,alignx left,aligny top");
			}
			{
				JLabel label = new JLabel("");
				panel.add(label, "cell 1 0,alignx left,aligny top");
			}
			{
				JLabel label = new JLabel("");
				panel.add(label, "cell 2 0,alignx left,aligny top");
			}
			{
				JLabel lblNewLabel = new JLabel("ID");
				//lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 11));
				lblNewLabel.setHorizontalTextPosition(SwingConstants.RIGHT);
				lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
				panel.add(lblNewLabel, "cell 3 1");
			}
			{
				idTF = new JTextField();
				idTF.setEnabled(false);
				idTF.setEditable(false);
				panel.add(idTF, "cell 5 1,growx");
				idTF.setColumns(10);
			}
			{
				JLabel lblNewLabel_1 = new JLabel("First Name");
				panel.add(lblNewLabel_1, "cell 3 2");
			}
			{
				fnameTF = new JTextField();
				panel.add(fnameTF, "cell 5 2,growx");
				fnameTF.setColumns(10);
			}
			{
				JLabel lblNewLabel_2 = new JLabel("Last Name");
				panel.add(lblNewLabel_2, "cell 3 3");
			}
			{
				lnameTF = new JTextField();
				panel.add(lnameTF, "cell 5 3,growx");
				lnameTF.setColumns(10);
			}
			{
				JLabel lblNewLabel_3 = new JLabel("Street");
				panel.add(lblNewLabel_3, "cell 3 4");
			}
			{
				streetTF = new JTextField();
				panel.add(streetTF, "cell 5 4,growx");
				streetTF.setColumns(10);
			}
			{
				JLabel lblNewLabel_4 = new JLabel("City");
				panel.add(lblNewLabel_4, "cell 3 5");
			}
			{
				cityTF = new JTextField();
				panel.add(cityTF, "cell 5 5,growx");
				cityTF.setColumns(10);
			}
			{
				JLabel lblNewLabel_5 = new JLabel("Postal Code");
				panel.add(lblNewLabel_5, "cell 3 6");
			}
			{
				postalTF = new JTextField();
				panel.add(postalTF, "cell 5 6,growx");
				postalTF.setColumns(10);
			}
			{
				JLabel lblNewLabel_6 = new JLabel("Phone");
				panel.add(lblNewLabel_6, "cell 3 7");
			}
			{
				phoneTF = new JTextField();
				panel.add(phoneTF, "cell 5 7,growx");
				phoneTF.setColumns(10);
			}
			{
				JLabel lblNewLabel_7 = new JLabel("Email");
				panel.add(lblNewLabel_7, "cell 3 8");
			}
			{
				emailTF = new JTextField();
				panel.add(emailTF, "cell 5 8,growx");
				emailTF.setColumns(10);
			}
			{
				JLabel lblNewLabel_8 = new JLabel("Joined Date");
				panel.add(lblNewLabel_8, "cell 3 9");
			}
			{
				dateTF = new JTextField();
				panel.add(dateTF, "cell 5 9,growx");
				dateTF.setColumns(10);
			}
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}

	
	private void init() {
		setTitle("Customer Info");
		setBounds(100, 100, 451, 424);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JPanel panel = new JPanel();
			panel.setBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null));
			contentPanel.add(panel);
			panel.setLayout(new MigLayout("", "[1px][1px][1px][][][grow]", "[1px][][][][][][][][][]"));
			{
				JLabel label = new JLabel("");
				panel.add(label, "cell 0 0,alignx left,aligny top");
			}
			{
				JLabel label = new JLabel("");
				panel.add(label, "cell 1 0,alignx left,aligny top");
			}
			{
				JLabel label = new JLabel("");
				panel.add(label, "cell 2 0,alignx left,aligny top");
			}
			{
				JLabel lblNewLabel = new JLabel("ID");
				//lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 11));
				lblNewLabel.setHorizontalTextPosition(SwingConstants.RIGHT);
				lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
				panel.add(lblNewLabel, "cell 3 1");
			}
			{
				idTF = new JTextField();
				//idTF.setEnabled(false);
				idTF.setEditable(false);
				Integer i = customer.getID();
				String is = i.toString();
				idTF.setText(is);
				panel.add(idTF, "cell 5 1,growx");
				idTF.setColumns(10);
			}
			{
				JLabel lblNewLabel_1 = new JLabel("First Name");
				panel.add(lblNewLabel_1, "cell 3 2");
			}
			{
				fnameTF = new JTextField();
				fnameTF.setText(customer.getFirstName());
				panel.add(fnameTF, "cell 5 2,growx");
				fnameTF.setColumns(10);
			}
			{
				JLabel lblNewLabel_2 = new JLabel("Last Name");
				panel.add(lblNewLabel_2, "cell 3 3");
			}
			{
				lnameTF = new JTextField();
				lnameTF.setText(customer.getLastName());
				panel.add(lnameTF, "cell 5 3,growx");
				lnameTF.setColumns(10);
			}
			{
				JLabel lblNewLabel_3 = new JLabel("Street");
				panel.add(lblNewLabel_3, "cell 3 4");
			}
			{
				streetTF = new JTextField();
				streetTF.setText(customer.getStreetName());
				panel.add(streetTF, "cell 5 4,growx");
				streetTF.setColumns(10);
			}
			{
				JLabel lblNewLabel_4 = new JLabel("City");
				panel.add(lblNewLabel_4, "cell 3 5");
			}
			{
				cityTF = new JTextField();
				cityTF.setText(customer.getCity());
				panel.add(cityTF, "cell 5 5,growx");
				cityTF.setColumns(10);
			}
			{
				JLabel lblNewLabel_5 = new JLabel("Postal Code");
				panel.add(lblNewLabel_5, "cell 3 6");
			}
			{
				postalTF = new JTextField();
				postalTF.setText(customer.getPostal());
				panel.add(postalTF, "cell 5 6,growx");
				postalTF.setColumns(10);
			}
			{
				JLabel lblNewLabel_6 = new JLabel("Phone");
				panel.add(lblNewLabel_6, "cell 3 7");
			}
			{
				phoneTF = new JTextField();
				phoneTF.setText(customer.getPhone());
				panel.add(phoneTF, "cell 5 7,growx");
				phoneTF.setColumns(10);
			}
			{
				JLabel lblNewLabel_7 = new JLabel("Email");
				panel.add(lblNewLabel_7, "cell 3 8");
			}
			{
				emailTF = new JTextField();
				emailTF.setText(customer.getEmail());
				panel.add(emailTF, "cell 5 8,growx");
				emailTF.setColumns(10);
			}
			{
				JLabel lblNewLabel_8 = new JLabel("Joined Date");
				panel.add(lblNewLabel_8, "cell 3 9");
			}
			{
				dateTF = new JTextField();
				dateTF.setText(customer.getDateString());
				panel.add(dateTF, "cell 5 9,growx");
				dateTF.setColumns(10);
			}
		}
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
	}
}
