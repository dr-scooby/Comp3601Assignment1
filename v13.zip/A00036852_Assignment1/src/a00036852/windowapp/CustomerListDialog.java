package a00036852.windowapp;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import a00036852.dao.data.Customer;
import net.miginfocom.swing.MigLayout;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Frame;

import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Iterator;


public class CustomerListDialog extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTable table;
	private DefaultTableModel tablemodel; // used for the JTable model
	
	private ArrayList<Customer> customers;
	
	private int selectedid;
	
	private Frame parentframe;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			CustomerListDialog dialog = new CustomerListDialog();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public CustomerListDialog(Frame f, ArrayList<Customer> customers) {
		// call super, and true means this dialog is like a child of frame
		// so user can't click on Main window when this dialog is open
		super(f, true);
		this.parentframe= f; 
		this.customers = customers; // init this first
		// then call init to create JSwing components
		init();
	}
	
	/**
	 * Take a parent Frame
	 * @param f Frame
	 */
	public CustomerListDialog(Frame f) {
		// call super, and true means this dialog is like a child of frame
		// so user can't click on Main window when this dialog is open
		super(f, true);
		
		init();
//		setBounds(100, 100, 474, 535);
//		getContentPane().setLayout(new BorderLayout());
//		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
//		getContentPane().add(contentPanel, BorderLayout.CENTER);
//		contentPanel.setLayout(new BorderLayout(0, 0));
//		{
//			JPanel panel = new JPanel();
//			contentPanel.add(panel);
//			panel.setLayout(new MigLayout("", "[][][][][grow]", "[][][grow]"));
//			{
//				JLabel lblNewLabel = new JLabel("Customers");
//				lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 14));
//				panel.add(lblNewLabel, "cell 4 0");
//			}
//			{
//				JList list = new JList();
//				panel.add(list, "cell 0 2 5 1,grow");
//			}
//		}
//		{
//			JPanel buttonPane = new JPanel();
//			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
//			getContentPane().add(buttonPane, BorderLayout.SOUTH);
//			{
//				JButton okButton = new JButton("OK");
//				okButton.addActionListener(new ActionListener() {
//					public void actionPerformed(ActionEvent e) {
//						System.out.println("ok button");
//						setVisible(true);
//					}
//				});
//				okButton.setActionCommand("OK");
//				buttonPane.add(okButton);
//				getRootPane().setDefaultButton(okButton);
//			}
//			{
//				JButton cancelButton = new JButton("Cancel");
//				cancelButton.addActionListener(new ActionListener() {
//					public void actionPerformed(ActionEvent e) {
//						
//						setVisible(false);
//					}
//				});
//				cancelButton.setActionCommand("Cancel");
//				buttonPane.add(cancelButton);
//			}
//		}
	}

	/**
	 * Create the dialog.
	 */
	public CustomerListDialog() {
		init();
//		setBounds(100, 100, 474, 535);
//		getContentPane().setLayout(new BorderLayout());
//		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
//		getContentPane().add(contentPanel, BorderLayout.CENTER);
//		contentPanel.setLayout(new BorderLayout(0, 0));
//		{
//			JPanel panel = new JPanel();
//			contentPanel.add(panel);
//			panel.setLayout(new MigLayout("", "[grow][][][][grow][][grow]", "[][grow][grow]"));
//			{
//				JLabel lblNewLabel = new JLabel("Customers");
//				lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
//				lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 14));
//				panel.add(lblNewLabel, "cell 4 0,alignx center");
//			}
//			{
//				// dummy data
//				String[] colNames = {"First Name", "Last Name", "Phone", "Email"};
//				Object[][] data = { {"Jahangir", "ismail", "911", "hijahangir@hotmail.com"},  {"Umar", "ismail", "611", "hiumar@hotmail.com"}, {"saf", "ismail", "011", "safiyah@hotmail.com"}};
//				{
//					JScrollPane scrollPane = new JScrollPane();
//					panel.add(scrollPane, "cell 0 1 7 1,grow");
//					table = new JTable(data, colNames);
//					table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
//					ListSelectionModel rowSM = table.getSelectionModel();
//		            rowSM.addListSelectionListener(new ListSelectionListener() {
//		                public void valueChanged(ListSelectionEvent e) {
//		                    //Ignore extra messages.
//		                    if (e.getValueIsAdjusting()) return;
//
//		                    ListSelectionModel lsm = (ListSelectionModel)e.getSource();
//		                    if (lsm.isSelectionEmpty()) {
//		                        System.out.println("No rows are selected.");
//		                    } else {
//		                        int selectedRow = lsm.getMinSelectionIndex();
//		                        System.out.println("\nRow " + selectedRow + " is now selected.\n");
//		                        printDebugData(table, selectedRow);
//		                    }
//		                }
//		            });
//		            
////					table.addMouseListener(new MouseAdapter() {
////		                public void mouseClicked(MouseEvent e) {
////		                    printDebugData(table);
////		                }
////		            });
//					scrollPane.setViewportView(table);
//				}
//			}
//		}
//		{
//			JPanel buttonPane = new JPanel();
//			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
//			getContentPane().add(buttonPane, BorderLayout.SOUTH);
//			{
//				JButton okButton = new JButton("OK");
//				okButton.addActionListener(new ActionListener() {
//					public void actionPerformed(ActionEvent e) {
//						System.out.println("ok button");
//						setVisible(false);
//					}
//				});
//				okButton.setActionCommand("OK");
//				buttonPane.add(okButton);
//				getRootPane().setDefaultButton(okButton);
//			}
//			{
//				JButton cancelButton = new JButton("Cancel");
//				cancelButton.addActionListener(new ActionListener() {
//					public void actionPerformed(ActionEvent e) {
//						setVisible(false);
//					}
//				});
//				cancelButton.setActionCommand("Cancel");
//				buttonPane.add(cancelButton);
//			}
//		}
	}// end constructor
	
	
	private void init() {
		setBounds(100, 100, 474, 535);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		{
			JPanel panel = new JPanel();
			contentPanel.add(panel);
			panel.setLayout(new MigLayout("", "[grow][][][][grow][][grow]", "[][grow][grow]"));
			{
				JLabel lblNewLabel = new JLabel("Customers");
				lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
				lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 14));
				panel.add(lblNewLabel, "cell 4 0,alignx center");
			}
			{
				if(customers != null) {
					String[] colNames = {"CustomerID", "FirstName", "LastName", "Phone", "JoinDate"};
					tablemodel = new DefaultTableModel();
					tablemodel.addColumn("CustomerID");
					tablemodel.addColumn("FirstName");
					tablemodel.addColumn("LastName");
					tablemodel.addColumn("Phone");
					tablemodel.addColumn("JoinDate");
					Customer c = null;
					int id = 0; 
					String fname = "" ; 
					String lname = "";
					String phone = "";
					String date = "";
					
					Iterator it = customers.iterator();
					while(it.hasNext()) {
						c = (Customer)it.next();
						id = c.getID();
						fname = c.getFirstName();
						lname = c.getLastName() ;
						phone = c.getPhone();
						date = c.getDateString();
						tablemodel.addRow(new Object[] {id, fname, lname, phone, date});
						 
					}
				}else {
				// dummy data
				String[] colNames = {"First Name", "Last Name", "Phone", "Email"};
				Object[][] data = { {"Jahangir", "ismail", "911", "hijahangir@hotmail.com"},  {"Umar", "ismail", "611", "hiumar@hotmail.com"}, {"saf", "ismail", "011", "safiyah@hotmail.com"}};
				tablemodel = new DefaultTableModel();
				
				tablemodel.addColumn("First Name");
				tablemodel.addColumn("Last Name");
				tablemodel.addColumn("Phone");
				tablemodel.addColumn("Email");
				
				tablemodel.addRow(new Object[]{"Jahangir", "ismail", "911", "hijahangir@hotmail.com"});
				tablemodel.addRow(new Object[]{"Umar", "ismail", "611", "hiumar@hotmail.com"});
				tablemodel.addRow(new Object[]{"saf", "ismail", "011", "safiyah@hotmail.com"});
				}
				
				{
					JScrollPane scrollPane = new JScrollPane();
					panel.add(scrollPane, "cell 0 1 7 1,grow");
					//table = new JTable(data, colNames);
					// add the table model, and turn off cell editing
					table = new JTable(tablemodel) {
						public boolean editCellAt(int row, int column, java.util.EventObject e) {
							return false;
						}
					};
					// add mouse listener to detect double mouse clicks
					table.addMouseListener(new MouseAdapter() {
				         public void mouseClicked(MouseEvent me) {
				             if (me.getClickCount() == 2) {     // to detect doble click events
				                JTable target = (JTable)me.getSource();
				                //selectedid = (int)model.getValueAt(row, 0);
				                javax.swing.table.TableModel model = target.getModel();
				                int row = target.getSelectedRow(); // select a row
				                int column = target.getSelectedColumn(); // select a column
				                selectedid = (int)model.getValueAt(row, 0);
				               //JOptionPane.showMessageDialog(null, table.getValueAt(row, column)); // get the value of a row and column.
				               Customer c = getCustomer(selectedid);
				               if( c != null) {
				            	   System.out.println("not null: " + c);
				            	   CustomerInfoDialog dialog = new CustomerInfoDialog(parentframe, c);
				       				dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				       				dialog.setVisible(true);
				               }else
				            	   System.out.println("null Customer");
				               
				             }
				          }
				       });
					// add ListSelection - only allow single selection
					table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
//					ListSelectionModel rowSM = table.getSelectionModel();
//		            rowSM.addListSelectionListener(new ListSelectionListener() {
//		                public void valueChanged(ListSelectionEvent e) {
//		                    //Ignore extra messages.
//		                    if (e.getValueIsAdjusting()) return;
//
//		                    ListSelectionModel lsm = (ListSelectionModel)e.getSource();
//		                    if (lsm.isSelectionEmpty()) {
//		                        System.out.println("No rows are selected.");
//		                    } else {
//		                        int selectedRow = lsm.getMinSelectionIndex();
//		                        System.out.println("\nRow " + selectedRow + " is now selected.\n");
//		                        printDebugData(table, selectedRow);
//		                    }
//		                }
//		            });
		            
//					table.addMouseListener(new MouseAdapter() {
//		                public void mouseClicked(MouseEvent e) {
//		                    printDebugData(table);
//		                }
//		            });
					scrollPane.setViewportView(table);
				}
			}
		}
		{
			JPanel buttonPane = new JPanel();
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Ok");
				okButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						System.out.println("ok button");
						setVisible(false);
					}
				});
				buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
		}
	}
	
	
	
	private Customer getCustomer(int find) {
		Customer c = null;
		Iterator it = customers.iterator();
		while(it.hasNext()) {
			 c = (Customer)it.next();
			if(c.getID() == find) {
				System.out.println("\nfound: " + c);
				return c;
			}
		}
		
		return c;
	}
	
	
	private void printDebugData(JTable t, int row) {
		int numCols = t.getColumnCount();
		javax.swing.table.TableModel model = t.getModel();
		for (int j=0; j < numCols; j++) {
            System.out.println(" Data Row:>> " + model.getValueAt(row, j));
        }
		selectedid = (int)model.getValueAt(row, 0);
		System.out.println("Selected ID:>> " + selectedid);
	}
	
	private void printDebugData(JTable t) {
		int numRows = t.getRowCount();
        int numCols = t.getColumnCount();
        javax.swing.table.TableModel model = t.getModel();
        
        System.out.println("Value of data: ");
        for (int i=0; i < numRows; i++) {
            System.out.print("    row " + i + ":");
            for (int j=0; j < numCols; j++) {
                System.out.print("  " + model.getValueAt(i, j));
            }
            System.out.println();
        }
        System.out.println("--------------------------");
	}

}
