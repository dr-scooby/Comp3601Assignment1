package a00036852.data.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * @author  Jahangir Ismail
 * Student ID: A00036852
 *  Validator is a utility class to validate proper email, or phone, or postal, etc..
 *  A helper class.
 *  @version 1
 */
public class Validator {
	
	
	
	
	// validate email to make sure it's on the pattern word@domain.com or .net
	/**
	 * 
	 * @param email - take a String email
	 * @return return the result String, validate the incoming String is a proper email 
	 */
	public static String processEmail(String email) {
			//System.out.println("\nvalidting email..\n");
			String result = "";
			//([\w\.\w]+@[a-zA-Z_]+?\.[a-zA-Z]{2,6})
			//(\\w\\.+\\w+@[a-zA-Z_]+?\\.[a-zA-Z]{2,6})
			//([\w\.\w]+@[a-zA-Z_]*?\.[a-zA-Z_.]{2,6})
			String regex = "([\\w\\.\\w]+@[a-zA-Z_]*?\\.[a-zA-Z_.]{2,6})"; // email pattern
			
			Pattern patt = Pattern.compile(regex);
			Matcher match = patt.matcher(email);
			if(match.matches()) {
				System.out.println("\n*** Valid email: " + email + "\n");
				result = email;
			}else {
				System.out.println("\n>>> Invalid email: " + email);
				result = "n/a";
			}
			
			return result;
		}
	
	
	// take a date string, and return a LocalDate Object
	// eg. 20080322 
	/**
	 * 
	 * @param String s
	 * @return LocalDate
	 */
	public static LocalDate processDate(String s) {
		String dates = s;
		//String dates = "20080322";
		// first 4 characters is the year
		String year =  dates.substring(0, 4);
		// next 2 is the month
		String month =  dates.substring(4, 6);
		// next 2 is the day
		String day = dates.substring(6, 8);
		
		// manually take a string of 20080322 and add dashes
		// get an exception if doing LocalDate parse of
        String formatdate = year+"-"+month+"-"+day;
        // parse it to the LocalDate
		LocalDate localdate = LocalDate.parse(formatdate);		
		
		// return the LocalDate object       
		return localdate   ;
	}

}
