/**
 * 
 */
package a00036852.data.util;

import java.util.Comparator;

import a00036852.dao.data.Customer;

/**
 * Sort Customers by ID
 * @author Jahangir Ismail
 * Student ID: A00036852
 * Created on Feb. 24, 2022 
 */
public class CompareById implements Comparator<Customer>{
	
	/**
	 * Take 2 Customer objects, and sort by the ID
	 * @param Customer c1
	 * @param Customer c2
	 * @return int
	 */
	public int compare(Customer c1, Customer c2) {
		
				
		return c1.getID() - c2.getID();
		
	}

}
