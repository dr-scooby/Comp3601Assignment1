/**
 * 
 */
package a00036852.dao;

import java.sql.SQLException;

import a00036852.database.Database;

/**
 * @author Jahangir Ismail
 * Student ID: A00036852
 * Created on Feb. 11, 2022 
 */
public abstract class Dao {

	// the table name
	protected final String tablename;
	// handle to the Database
	protected final Database db;
	
	
	/**
	 * 
	 * @param d Database
	 * @param tablename String name of table
	 */
	protected Dao(Database d, String tablename) {
		this.tablename = tablename;
		this.db = d;
	}
	
	// the abstract create
	/**
	 * abstract create Table
	 * @throws SQLException
	 */
	public abstract void create() throws SQLException;
	
	
	// create a Table using an sql statement
	/**
	 * 
	 * @param sql SQL statement
	 * @throws SQLException
	 */
	protected void create(String sql) throws SQLException {
		//System.out.println("in DAO, create: " + sql);
		db.creatTable(sql);
		
	}
	
	/**
	 * 
	 * @param sql String SQL
	 * @throws SQLException
	 */
	protected void add(String sql) throws SQLException {
		
		//System.out.println("in DAO, add: " + sql);
		db.insert(sql);
		
	}
	
	
}
