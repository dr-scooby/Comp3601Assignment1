/**
 * 
 */
package appmain;

import java.awt.EventQueue;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.UIManager;

import a00036852.dao.CustomerDAO;
import a00036852.dao.data.Customer;
import a00036852.data.util.ProcessArray;
import a00036852.database.DBConstants;
import a00036852.database.Database;
import a00036852.io.ReadDataFile;
import a00036852.windowapp.JApp;

/**
 * @author Jahangir Ismail
 * Student ID: A00036852
 * Created on Feb. 14, 2022 9:05:28 p.m.
 */
public class Main {
	
	private Database db;
	private CustomerDAO customerdao;
	
	
	public Main() {
		System.out.println("Starting main...");
		
		// init the DB
		db = new Database();
		
		db.connect(); // connect to Db
			try {
				// get the Customer table name
				String table = DBConstants.CUSTOMER_TABLE;
				// drop table if already exists...?
				if(db.tableExists(table)) { // check if table already exists
					customerdao = new CustomerDAO(db);
					// display
					//display();
//					try {
//						if(db.dropTable(DBConstants.CUSTOMER_TABLE)) {
//							System.out.println("Dropped the table");
//							
//						load();
//						}
//						//db.shutdown(); // shutdown the db
//						//System.exit(-1); // exit the app
//					} catch (SQLException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
				}else {
					// table doesn't exist, load data
					load();
					//test();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
//			// do a simple check, tests if Derby connection is working
//			if(db.tableExists("pets"))
//				System.out.println("pets exists");
//			else
//				System.out.println("pets doesn't exist");
			
			
		
		
		// read data file
		
		// run the Window Frame
			try {
				UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
			} catch (Exception ex) {
				// ignore it
			}
		EventQueue.invokeLater(new Runnable() {
			
			public void run() {
				try {
					JApp window = new JApp();
					window.setCustomerDAO(customerdao);
					window.setDB(db);
					window.show();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		//db.shutdown(); // shut down DB
	}
	
	
	// get data from DB
	private void loadDB() {
		// create a DAO object of Customer
		customerdao = new CustomerDAO(db);
		
	}
	
	// read the data file, and load into db 
	private void load() {
		// read the data file
		ReadDataFile rf =  new ReadDataFile();
		// get a raw array from the file
		ArrayList<String> data = rf.getDataArray();
		// process the array and convert to Customers
		ProcessArray pd = new ProcessArray(data);
		// create a DAO object of Customer
		customerdao = new CustomerDAO(db);
		try {
			customerdao.create(); // create table
			Iterator it = pd.getIt(); // iterate over array
			System.out.println("the ID's: ");
			while(it.hasNext()){
				Customer c = (Customer)it.next(); // get the Customer
				System.out.println( c.getID());
				customerdao.add(c); // add to the DB
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		
		
	public static void main(String[] args) {
		new Main();
	}

}
