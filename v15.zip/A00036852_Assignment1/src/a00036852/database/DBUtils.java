/**
 * 
 */
package a00036852.database;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

/**
 * @author Jahangir Ismail
 * Student ID: A00036852
 * Created on Feb. 9, 2022 
 * 
 * Get DB info, file name needed from a properties file
 */
public class DBUtils {
	
	
	private File dbPropertiesFile;
	private Properties properties;
	
	private String dbdriver;
	private String url;
	
	private String dbuser;
	private String dbpassword;
	
	private String datafile;
	
	public DBUtils() {
		dbPropertiesFile = new File(DBConstants.DB_PROPERTIES_FILENAME);
		if (!dbPropertiesFile.exists()) {
			System.out.println("properties file doesn't exist");
			System.exit(-1);
		}else {
			properties = new Properties();
			try {
				FileInputStream in = new FileInputStream(dbPropertiesFile);
				properties.load(in);
				//properties.list(System.out);
				
				// get name value pairs
				//System.out.println("DB Driver: " + properties.getProperty("derbydb.driver"));
				//System.out.println("URL: " + properties.getProperty("derbydb.url"));
				
				dbdriver = properties.getProperty("derbydb.driver");
				url = properties.getProperty("derbydb.url");
				dbuser = properties.getProperty("db.user");
				dbpassword = properties.getProperty("db.password");
				datafile = properties.getProperty("datafile");
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	public String getDBDriver() {
		return dbdriver;
	}
	
	public String getURL() {
		return url;
	}
	
	public String getDBUser() {
		return dbuser;
	}
	
	public String getDBPassword() {
		return dbpassword;
	}

	public String getDataFile() {
		return datafile;
	}
}
