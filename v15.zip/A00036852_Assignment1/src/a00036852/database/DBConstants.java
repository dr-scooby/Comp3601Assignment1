/**
 * 
 */
package a00036852.database;

/**
 * @author Jahangir Ismail
 * Student ID: A00036852
 * Created on Feb. 9, 2022 
 */
public interface DBConstants {
	
	String DB_PROPERTIES_FILENAME = "db.properties";
	
	String FILENAME = "data/customers.txt";
	
	String DB_USER = "admin";
	String DB_PASSWORD = "admin";
	
	String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
	String URL = "jdbc:derby:derby_jdbc_test;create=true";
	
	String CUSTOMER_TABLE = "Customers";

}
